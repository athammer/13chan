


$(document).ready(function (){
    // $('form > input').keyup(function() {
    //     var pass = $("newPassword").val();
    //     var pass1 = $("newPassword1").val();
    //     if(pass = pass1){
            
    //     }else{
            
    //     }
    
    // });
    
    
});