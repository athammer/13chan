var userModel = require('../../models/board.js');

module.exports = {   
    
    createboard: function(req, res, next) {
        
    }
};
